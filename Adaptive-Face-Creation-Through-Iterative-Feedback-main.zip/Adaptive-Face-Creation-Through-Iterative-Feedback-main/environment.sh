ml purge
module load Mamba/23.11.0-0
source activate qj3-pytorch-2.4.1-cuda-12.4